--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.5 (Ubuntu 15.5-0ubuntu0.23.10.1)
-- Dumped by pg_dump version 15.5 (Ubuntu 15.5-0ubuntu0.23.10.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE dbms;
--
-- Name: dbms; Type: DATABASE; Schema: -; Owner: rohi
--

CREATE DATABASE dbms WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE dbms OWNER TO rohi;

\connect dbms

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: add_employee(character varying, character varying, integer); Type: FUNCTION; Schema: public; Owner: rohi
--

CREATE FUNCTION public.add_employee(emp_name character varying, emp_contact character varying, emp_branch_id integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    empid_var INTEGER;
BEGIN
    -- Start a new transaction block
    BEGIN
        -- Insert into employee table
        INSERT INTO public.employee (name,bcontact) VALUES (emp_name,emp_contact)
        RETURNING empid INTO empid_var; -- Assuming empid is SERIAL type and auto-generated
        
        -- Insert into worksin table associating employee with branch
        INSERT INTO public.worksin (empid, bid) VALUES (empid_var, emp_branch_id);
        
        -- If there's any other data you want to update for the employee, you can do it here
        
        -- If all operations succeed, commit the transaction

    EXCEPTION
        WHEN others THEN
            -- If an error occurs, rollback the transaction
            ROLLBACK;
            RAISE;
    END;
END;
$$;


ALTER FUNCTION public.add_employee(emp_name character varying, emp_contact character varying, emp_branch_id integer) OWNER TO rohi;

--
-- Name: book_car(integer, integer, integer, date, date); Type: FUNCTION; Schema: public; Owner: rohi
--

CREATE FUNCTION public.book_car(customer_id integer, car_id integer, employee_id integer, booking_from_date date, booking_to_date date) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    car_available BOOLEAN;
BEGIN
    -- Check if the car is available
    SELECT is_avail INTO car_available FROM public.car WHERE carid = car_id;

    IF car_available THEN
        -- Insert booking details
        INSERT INTO public.booking (carid, cid, fromdate, todate)
        VALUES (car_id, customer_id, booking_from_date, booking_to_date);

        -- Insert handler details
        INSERT INTO public.handler (empid, carid)
        VALUES (employee_id, car_id);

        -- Update is_avail to false after booking
        UPDATE public.car SET is_avail = false WHERE carid = car_id;
        
    ELSE
        RAISE EXCEPTION 'Car is not available for booking';
    END IF;
END;
$$;


ALTER FUNCTION public.book_car(customer_id integer, car_id integer, employee_id integer, booking_from_date date, booking_to_date date) OWNER TO rohi;

--
-- Name: update_car_availability(); Type: FUNCTION; Schema: public; Owner: rohi
--

CREATE FUNCTION public.update_car_availability() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE public.car c
    SET is_avail = true
    WHERE EXISTS (
        SELECT 1 FROM public.booking b
        WHERE b.carid = c.carid AND b.todate < CURRENT_DATE
    );
    RETURN NULL;
END;
$$;


ALTER FUNCTION public.update_car_availability() OWNER TO rohi;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: auth; Type: TABLE; Schema: public; Owner: rohi
--

CREATE TABLE public.auth (
    email character varying(100) NOT NULL,
    password character varying(20)
);


ALTER TABLE public.auth OWNER TO rohi;

--
-- Name: booking; Type: TABLE; Schema: public; Owner: rohi
--

CREATE TABLE public.booking (
    bookid integer NOT NULL,
    carid integer,
    cid integer,
    fromdate date,
    todate date
);


ALTER TABLE public.booking OWNER TO rohi;

--
-- Name: booking_bookid_seq; Type: SEQUENCE; Schema: public; Owner: rohi
--

ALTER TABLE public.booking ALTER COLUMN bookid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.booking_bookid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: branch; Type: TABLE; Schema: public; Owner: rohi
--

CREATE TABLE public.branch (
    bid integer NOT NULL,
    bcity character varying(50),
    bname character varying(50),
    bcontact character varying(10)
);


ALTER TABLE public.branch OWNER TO rohi;

--
-- Name: car; Type: TABLE; Schema: public; Owner: rohi
--

CREATE TABLE public.car (
    carid integer NOT NULL,
    brand character varying(30),
    name character varying(30),
    mil integer,
    is_avail boolean,
    price integer NOT NULL
);


ALTER TABLE public.car OWNER TO rohi;

--
-- Name: handler; Type: TABLE; Schema: public; Owner: rohi
--

CREATE TABLE public.handler (
    empid integer,
    carid integer
);


ALTER TABLE public.handler OWNER TO rohi;

--
-- Name: worksin; Type: TABLE; Schema: public; Owner: rohi
--

CREATE TABLE public.worksin (
    empid integer,
    bid integer
);


ALTER TABLE public.worksin OWNER TO rohi;

--
-- Name: car_branch_count; Type: VIEW; Schema: public; Owner: rohi
--

CREATE VIEW public.car_branch_count AS
 SELECT b.bname AS branch_name,
    count(*) AS cars_booked
   FROM (((public.branch b
     JOIN public.worksin w ON ((b.bid = w.bid)))
     JOIN public.handler h ON ((w.empid = h.empid)))
     JOIN public.booking bo ON ((h.carid = bo.carid)))
  GROUP BY b.bname;


ALTER TABLE public.car_branch_count OWNER TO rohi;

--
-- Name: car_carid_seq; Type: SEQUENCE; Schema: public; Owner: rohi
--

ALTER TABLE public.car ALTER COLUMN carid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.car_carid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: customer; Type: TABLE; Schema: public; Owner: rohi
--

CREATE TABLE public.customer (
    cid integer NOT NULL,
    name character varying(30),
    contact character varying(10)
);


ALTER TABLE public.customer OWNER TO rohi;

--
-- Name: customer_cid_seq; Type: SEQUENCE; Schema: public; Owner: rohi
--

ALTER TABLE public.customer ALTER COLUMN cid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.customer_cid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: customer_id_seq; Type: SEQUENCE; Schema: public; Owner: rohi
--

CREATE SEQUENCE public.customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customer_id_seq OWNER TO rohi;

--
-- Name: customer_summary; Type: VIEW; Schema: public; Owner: rohi
--

CREATE VIEW public.customer_summary AS
 SELECT b.cid AS user_id,
    cu.name AS customer_name,
    cu.contact AS customer_contact,
    sum((c.price * ((b.todate - b.fromdate) + 1))) AS total_amount_spent
   FROM ((public.booking b
     JOIN public.car c ON ((b.carid = c.carid)))
     JOIN public.customer cu ON ((b.cid = cu.cid)))
  GROUP BY b.cid, cu.name, cu.contact;


ALTER TABLE public.customer_summary OWNER TO rohi;

--
-- Name: employee; Type: TABLE; Schema: public; Owner: rohi
--

CREATE TABLE public.employee (
    empid integer NOT NULL,
    name character varying(20),
    bcontact character varying(10)
);


ALTER TABLE public.employee OWNER TO rohi;

--
-- Name: employee_empid_seq; Type: SEQUENCE; Schema: public; Owner: rohi
--

ALTER TABLE public.employee ALTER COLUMN empid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.employee_empid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: auth; Type: TABLE DATA; Schema: public; Owner: rohi
--

COPY public.auth (email, password) FROM stdin;
\.
COPY public.auth (email, password) FROM '$$PATH$$/3451.dat';

--
-- Data for Name: booking; Type: TABLE DATA; Schema: public; Owner: rohi
--

COPY public.booking (bookid, carid, cid, fromdate, todate) FROM stdin;
\.
COPY public.booking (bookid, carid, cid, fromdate, todate) FROM '$$PATH$$/3444.dat';

--
-- Data for Name: branch; Type: TABLE DATA; Schema: public; Owner: rohi
--

COPY public.branch (bid, bcity, bname, bcontact) FROM stdin;
\.
COPY public.branch (bid, bcity, bname, bcontact) FROM '$$PATH$$/3439.dat';

--
-- Data for Name: car; Type: TABLE DATA; Schema: public; Owner: rohi
--

COPY public.car (carid, brand, name, mil, is_avail, price) FROM stdin;
\.
COPY public.car (carid, brand, name, mil, is_avail, price) FROM '$$PATH$$/3443.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: rohi
--

COPY public.customer (cid, name, contact) FROM stdin;
\.
COPY public.customer (cid, name, contact) FROM '$$PATH$$/3442.dat';

--
-- Data for Name: employee; Type: TABLE DATA; Schema: public; Owner: rohi
--

COPY public.employee (empid, name, bcontact) FROM stdin;
\.
COPY public.employee (empid, name, bcontact) FROM '$$PATH$$/3440.dat';

--
-- Data for Name: handler; Type: TABLE DATA; Schema: public; Owner: rohi
--

COPY public.handler (empid, carid) FROM stdin;
\.
COPY public.handler (empid, carid) FROM '$$PATH$$/3445.dat';

--
-- Data for Name: worksin; Type: TABLE DATA; Schema: public; Owner: rohi
--

COPY public.worksin (empid, bid) FROM stdin;
\.
COPY public.worksin (empid, bid) FROM '$$PATH$$/3441.dat';

--
-- Name: booking_bookid_seq; Type: SEQUENCE SET; Schema: public; Owner: rohi
--

SELECT pg_catalog.setval('public.booking_bookid_seq', 20, true);


--
-- Name: car_carid_seq; Type: SEQUENCE SET; Schema: public; Owner: rohi
--

SELECT pg_catalog.setval('public.car_carid_seq', 4, true);


--
-- Name: customer_cid_seq; Type: SEQUENCE SET; Schema: public; Owner: rohi
--

SELECT pg_catalog.setval('public.customer_cid_seq', 7, true);


--
-- Name: customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rohi
--

SELECT pg_catalog.setval('public.customer_id_seq', 1, false);


--
-- Name: employee_empid_seq; Type: SEQUENCE SET; Schema: public; Owner: rohi
--

SELECT pg_catalog.setval('public.employee_empid_seq', 8, true);


--
-- Name: auth auth_pkey; Type: CONSTRAINT; Schema: public; Owner: rohi
--

ALTER TABLE ONLY public.auth
    ADD CONSTRAINT auth_pkey PRIMARY KEY (email);


--
-- Name: booking booking_pkey; Type: CONSTRAINT; Schema: public; Owner: rohi
--

ALTER TABLE ONLY public.booking
    ADD CONSTRAINT booking_pkey PRIMARY KEY (bookid);


--
-- Name: branch branch_pkey; Type: CONSTRAINT; Schema: public; Owner: rohi
--

ALTER TABLE ONLY public.branch
    ADD CONSTRAINT branch_pkey PRIMARY KEY (bid);


--
-- Name: car car_pkey; Type: CONSTRAINT; Schema: public; Owner: rohi
--

ALTER TABLE ONLY public.car
    ADD CONSTRAINT car_pkey PRIMARY KEY (carid);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: rohi
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (cid);


--
-- Name: employee employee_pkey; Type: CONSTRAINT; Schema: public; Owner: rohi
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT employee_pkey PRIMARY KEY (empid);


--
-- Name: booking update_avail; Type: TRIGGER; Schema: public; Owner: rohi
--

CREATE TRIGGER update_avail AFTER INSERT OR DELETE OR UPDATE ON public.booking FOR EACH ROW EXECUTE FUNCTION public.update_car_availability();


--
-- Name: booking booking_carid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rohi
--

ALTER TABLE ONLY public.booking
    ADD CONSTRAINT booking_carid_fkey FOREIGN KEY (carid) REFERENCES public.car(carid);


--
-- Name: booking booking_cid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rohi
--

ALTER TABLE ONLY public.booking
    ADD CONSTRAINT booking_cid_fkey FOREIGN KEY (cid) REFERENCES public.customer(cid);


--
-- Name: handler handler_carid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rohi
--

ALTER TABLE ONLY public.handler
    ADD CONSTRAINT handler_carid_fkey FOREIGN KEY (carid) REFERENCES public.car(carid);


--
-- Name: handler handler_empid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rohi
--

ALTER TABLE ONLY public.handler
    ADD CONSTRAINT handler_empid_fkey FOREIGN KEY (empid) REFERENCES public.employee(empid);


--
-- Name: worksin worksin_bid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rohi
--

ALTER TABLE ONLY public.worksin
    ADD CONSTRAINT worksin_bid_fkey FOREIGN KEY (bid) REFERENCES public.branch(bid);


--
-- Name: worksin worksin_empid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rohi
--

ALTER TABLE ONLY public.worksin
    ADD CONSTRAINT worksin_empid_fkey FOREIGN KEY (empid) REFERENCES public.employee(empid);


--
-- PostgreSQL database dump complete
--

